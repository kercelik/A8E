Place your Starter Kit PDF here, e.g., A8E-Starter-Kit.pdf.
